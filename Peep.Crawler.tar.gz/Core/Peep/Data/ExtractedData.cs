﻿using System;
using System.Collections.Generic;

namespace Peep.Data
{
    public class ExtractedData : Dictionary<Uri, IEnumerable<string>>
    {

    }
}