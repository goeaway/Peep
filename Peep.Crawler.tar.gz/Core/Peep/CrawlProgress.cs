﻿using System;
using System.Collections.Generic;
using System.Text;
using Peep.Data;

namespace Peep
{
    public class CrawlProgress
    {
        public ExtractedData Data { get; set; }
    }
}
