﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Peep.StopConditions
{
    public enum SerialisableStopConditionType
    {
        MaxCrawlCount,
        MaxDataCount,
        MaxDurationSeconds,
    }
}
