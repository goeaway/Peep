﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Peep.PageActions
{
    public enum SerialisablePageActionType
    {
        Wait,
        Click,
        Scroll
    }
}
