﻿using System.Collections.Generic;

namespace Peep.Core.Infrastructure.Data
{
    public class CrawlErrors : List<CrawlError>
    {
        
    }
}