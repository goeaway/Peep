﻿namespace Peep.Core.Infrastructure.Messages
{
    public class CrawlQueued 
    {
        public IdentifiableCrawlJob Job { get; set; }
    }
}
