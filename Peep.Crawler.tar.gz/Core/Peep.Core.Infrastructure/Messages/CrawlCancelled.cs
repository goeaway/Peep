﻿namespace Peep.Core.Infrastructure.Messages
{
    public class CrawlCancelled
    {
        public string CrawlId { get; set; }
    }
}
